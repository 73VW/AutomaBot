``AutomaBot``
=============
.. image:: https://travis-ci.org/73VW/AutomaBot.svg?branch=master
    :target: https://travis-ci.org/73VW/AutomaBot

Par Maël Pedretti [#mp]_ et Dany Chea [#dc]_

Automation Bot. Work in progress

.. [#mp] <mael.pedretti@he-arc.ch>
.. [#dc] <dany.chea@he-arc.ch>
